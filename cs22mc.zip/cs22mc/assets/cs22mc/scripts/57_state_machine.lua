-- ============================================================
-- Customizable State Machine for TACZ
-- Author: lolokeia
-- Base: tacz_default_state_machine
-- Features:
--   - Random animations for draw, inspect, reload (with weights)
--   - draw_empty support (configurable)
--   - Low ammo sound effect (triggered via animation)
--   - Burst fire mode support
-- ============================================================

local default = require("tacz_default_state_machine")
local STATIC_TRACK_LINE = default.STATIC_TRACK_LINE
local MAIN_TRACK = default.MAIN_TRACK
local main_track_states = default.main_track_states
local static_track_top = default.static_track_top

-- ========================== CONFIGURATION ==========================
-- Animation pools
local DRAW_ANIMS = {
    { name = "draw", weight = 100 },
}

local DRAW_EMPTY_ANIMS = {
    { name = "draw_empty", weight = 100 },
}

local INSPECT_ANIMS = {
    { name = "inspect", weight = 100 },
}

local INSPECT_EMPTY_ANIMS = {
    { name = "inspect_empty", weight = 100 },
}

local RELOAD_TACTICAL_ANIMS = {
    { name = "reload_tactical", weight = 100 },
}

local RELOAD_EMPTY_ANIMS = {
    { name = "reload_empty", weight = 100 },
}

-- Features toggles
local ENABLE_DRAW_EMPTY = true          -- play draw_empty when magazine is empty

-- Low ammo sound settings
local LOW_AMMO_PERCENT = 20             -- % of magazine capacity to start playing sound
-- ====================================================================

-- ========================== HELPER FUNCTIONS ==========================

-- Pick a random animation name from a weighted list
local function weightedRandom(anims)
    if #anims == 0 then return nil end
    local total = 0
    for _, a in ipairs(anims) do total = total + (a.weight or 1) end
    local r = math.random() * total
    local cumulative = 0
    for _, a in ipairs(anims) do
        cumulative = cumulative + (a.weight or 1)
        if r <= cumulative then return a.name end
    end
    return anims[1].name
end

-- Simple counter used for track allocation
local function increment(obj)
    obj.value = obj.value + 1
    return obj.value - 1
end

local FIRE_MODE_TRACK = increment(static_track_top)
local SWITCH_MODE_TRACK = increment(static_track_top)

-- Check if the gun has no ammunition
local function isNoAmmo(context)
    return (not context:hasBulletInBarrel()) and (context:getAmmoCount() <= 0)
end

-- Play a reload animation (randomly chosen from the respective pool)
local function runReloadAnimation(context)
    local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
    local animName
    if isNoAmmo(context) then
        animName = weightedRandom(RELOAD_EMPTY_ANIMS) or "reload_empty"
    else
        animName = weightedRandom(RELOAD_TACTICAL_ANIMS) or "reload_tactical"
    end
    context:runAnimation(animName, track, false, PLAY_ONCE_STOP, 0.2)
end

-- Get a random inspect animation name
local function getInspectAnimationName(context)
    if isNoAmmo(context) and #INSPECT_EMPTY_ANIMS > 0 then
        return weightedRandom(INSPECT_EMPTY_ANIMS)
    else
        return weightedRandom(INSPECT_ANIMS)
    end
end

-- ========================== STATES ==========================

-- Inspect state: plays a random inspect animation and hides crosshair
local inspect_state = setmetatable({
    entry = function(this, context)
        local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
        local animName = getInspectAnimationName(context) or "inspect"
        context:runAnimation(animName, track, false, PLAY_ONCE_STOP, 0.2)
        context:setShouldHideCrossHair(true)
    end,
    update = function(this, context)
        if context:isStopped(context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)) then
            context:trigger(this.INPUT_INSPECT_RETREAT)
        end
    end,
    transition = function(this, context, input)
        if input == this.INPUT_INSPECT_RETREAT then
            context:setShouldHideCrossHair(false)
            return this.main_track_states.idle
        end
        if input == INPUT_FIRE_SELECT then
            context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK))
            return this.main_track_states.idle
        end
        return main_track_states.inspect.transition(this, context, input)
    end,
    exit = function(this, context)
        context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK))
        context:setShouldHideCrossHair(false)
    end
}, {__index = main_track_states.inspect})

local idle_state = setmetatable({}, {__index = main_track_states.idle})

-- Start state: chooses a draw animation (possibly draw_empty) and then goes to idle
local start_state = setmetatable({}, {__index = main_track_states.start})
function start_state.transition(this, context, input)
    if input == INPUT_DRAW then
        local drawAnim
        if ENABLE_DRAW_EMPTY and isNoAmmo(context) and #DRAW_EMPTY_ANIMS > 0 then
            drawAnim = weightedRandom(DRAW_EMPTY_ANIMS)
        else
            drawAnim = weightedRandom(DRAW_ANIMS) or "draw"
        end
        context:runAnimation(drawAnim, context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), false, PLAY_ONCE_STOP, 0)
        return this.main_track_states.idle
    end
    return main_track_states.start.transition(this, context, input)
end

-- Idle state: handles reload, put_away, inspect, and adds low ammo sound on shoot
function idle_state.transition(this, context, input)
    if input == INPUT_RELOAD then
        local maxAmmo = context:getMaxAmmoCount()
        if maxAmmo and context:getAmmoCount() < maxAmmo then
            runReloadAnimation(context)
        end
        return this.main_track_states.idle
    end

    if input == INPUT_PUT_AWAY then
        local put_away_time = context:getPutAwayTime()
        local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
        context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK))
        context:runAnimation("put_away", track, false, PLAY_ONCE_HOLD, put_away_time * 0.75)
        context:setAnimationProgress(track, 1, true)
        context:adjustAnimationProgress(track, -put_away_time, false)
        return this.main_track_states.final
    end

    if input == INPUT_INSPECT then
        return inspect_state
    end

    -- Low ammo sound on shoot: triggers a dedicated animation that contains the sound effect
    if input == INPUT_SHOOT then
        local maxAmmo = context:getMaxAmmoCount()
        if maxAmmo and maxAmmo > 0 then
            local threshold = math.floor(maxAmmo * LOW_AMMO_PERCENT / 100)
            if context:getAmmoCount() <= threshold then
                context:runAnimation("low_ammo", context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), false, PLAY_ONCE_STOP, 0)
            end
        end
    end

    return main_track_states.idle.transition(this, context, input)
end

-- ========================== FIRE MODE HANDLING ==========================
-- Supports SEMI, BURST, AUTO (order defined in data file)
local fire_mode_state = {
    semi = {},
    auto = {},
    burst = {},
    draw = {}
}

function fire_mode_state.draw.update(this, context)
    context:trigger(this.INPUT_MODE_DRAW)
end

function fire_mode_state.draw.transition(this, context, input)
    if input == this.INPUT_MODE_DRAW then
        if context:getFireMode() == SEMI then
            context:runAnimation("static_semi", context:getTrack(STATIC_TRACK_LINE, FIRE_MODE_TRACK), true, PLAY_ONCE_HOLD, 0)
            return fire_mode_state.semi
        elseif context:getFireMode() == BURST then
            context:runAnimation("static_burst", context:getTrack(STATIC_TRACK_LINE, FIRE_MODE_TRACK), true, PLAY_ONCE_HOLD, 0)
            return fire_mode_state.burst
        elseif context:getFireMode() == AUTO then
            context:runAnimation("static_auto", context:getTrack(STATIC_TRACK_LINE, FIRE_MODE_TRACK), true, PLAY_ONCE_HOLD, 0)
            return fire_mode_state.auto
        end
    end
end

function fire_mode_state.semi.update(this, context)
    local track = context:getTrack(STATIC_TRACK_LINE, FIRE_MODE_TRACK)
    if context:isHolding(track) then
        context:runAnimation("static_semi", track, true, PLAY_ONCE_HOLD, 0)
    end
    if context:getFireMode() == BURST then
        context:trigger(this.INPUT_MODE_BURST)
    end
end

function fire_mode_state.semi.transition(this, context, input)
    if input == this.INPUT_MODE_BURST then
        context:runAnimation("switch_burst", context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK), false, PLAY_ONCE_STOP, 0)
        return fire_mode_state.burst
    end
    if input == INPUT_SHOOT then context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK)) end
    if input == INPUT_RELOAD then context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK)) end
    if input == INPUT_INSPECT then context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK)) end
end

function fire_mode_state.burst.update(this, context)
    local track = context:getTrack(STATIC_TRACK_LINE, FIRE_MODE_TRACK)
    if context:isHolding(track) then
        context:runAnimation("static_burst", track, true, PLAY_ONCE_HOLD, 0)
    end
    if context:getFireMode() == SEMI then
        context:trigger(this.INPUT_MODE_SEMI)
    end
end

function fire_mode_state.burst.transition(this, context, input)
    if input == this.INPUT_MODE_SEMI then
        context:runAnimation("switch_semi", context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK), false, PLAY_ONCE_STOP, 0)
        return fire_mode_state.semi
    end
    if input == INPUT_SHOOT then context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK)) end
    if input == INPUT_RELOAD then context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK)) end
    if input == INPUT_INSPECT then context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK)) end
end

function fire_mode_state.auto.update(this, context)
    local track = context:getTrack(STATIC_TRACK_LINE, FIRE_MODE_TRACK)
    if context:isHolding(track) then
        context:runAnimation("static_auto", track, true, PLAY_ONCE_HOLD, 0)
    end
    if context:getFireMode() == SEMI then
        context:trigger(this.INPUT_MODE_SEMI)
    end
end

function fire_mode_state.auto.transition(this, context, input)
    if input == this.INPUT_MODE_SEMI then
        context:runAnimation("switch_semi", context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK), false, PLAY_ONCE_STOP, 0)
        return fire_mode_state.semi
    end
    if input == INPUT_SHOOT then context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK)) end
    if input == INPUT_RELOAD then context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK)) end
    if input == INPUT_INSPECT then context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK)) end
end

-- ========================== ASSEMBLY ==========================
local M = setmetatable({
    main_track_states = setmetatable({
        idle = idle_state,
        inspect = inspect_state,
        start = start_state
    }, {__index = main_track_states}),
    FIRE_MODE_TRACK = FIRE_MODE_TRACK,
    SWITCH_MODE_TRACK = SWITCH_MODE_TRACK,
    INPUT_MODE_SEMI = "input_mode_semi",
    INPUT_MODE_AUTO = "input_mode_auto",
    INPUT_MODE_BURST = "input_mode_burst",
    INPUT_MODE_DRAW = "input_mode_draw",
    fire_mode_state = fire_mode_state,
    ADS_states = default.ADS_states
}, {__index = default})

function M:initialize(context)
    default.initialize(self, context)
end

function M:states()
    return {
        self.base_track_state,
        self.bolt_caught_states.normal,
        self.main_track_states.start,
        self.gun_kick_state,
        self.movement_track_states.idle,
        self.ADS_states.normal,
        self.slide_states.normal,
        self.fire_mode_state.draw
    }
end

return M