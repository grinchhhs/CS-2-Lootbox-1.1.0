local M = {}

function M.start_reload(api)
    -- Запрещаем перезарядку, если магазин уже полон
    if api:getNeededAmmoAmount() <= 0 then
        return false
    end
    return true
end

return M